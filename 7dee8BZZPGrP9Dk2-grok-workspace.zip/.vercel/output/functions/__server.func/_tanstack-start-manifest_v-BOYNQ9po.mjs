//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BOYNQ9po.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BJNki1Kc.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BJNki1Kc.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B4gfpWde.js"]
	}
} });
//#endregion
export { tsrStartManifest };
