import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Menu, c as Bone, i as Package, l as ArrowRight, o as Leaf, r as Sparkles, s as HeartPulse, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DmCzvUQm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var benefits = [
	{
		icon: Bone,
		title: "Joint comfort",
		copy: "Flower-rich pellets carry naturally occurring cannabinoids and terpenes barns look for when supporting mobility on the daily ration."
	},
	{
		icon: HeartPulse,
		title: "A quieter barn",
		copy: "Trainers use hemp flower as part of a calm-disposition routine — travel, show weeks, and horses that live a little loud."
	},
	{
		icon: Sparkles,
		title: "Coat & digestion",
		copy: "Essential fatty acids plus digestible fiber in a dense pellet that pours cleanly into the feed tub."
	}
];
var specs = [
	["Bag", "10 lb easy-pour feed bag"],
	["Price", "$24.95 CAD · $2.50 / lb"],
	["Form", "Pelletized hemp flower"],
	["Who it's for", "Barns, trainers, feed stores"]
];
function Home() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cream text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-line/80 bg-cream/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between px-5 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "flex items-center gap-2 font-display text-lg tracking-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-8 place-items-center rounded-full bg-forest text-cream",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
									className: "size-4",
									"aria-hidden": true
								})
							}), "Equine Hemp"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "hidden items-center gap-8 text-sm text-muted md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#product",
									className: "hover:text-ink",
									children: "The pellet"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#analysis",
									className: "hover:text-ink",
									children: "Lab analysis"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#benefits",
									className: "hover:text-ink",
									children: "Why barns buy it"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#process",
									className: "hover:text-ink",
									children: "How it's made"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#inquire",
									className: "rounded-full bg-forest px-4 py-2 text-cream hover:bg-forest-deep",
									children: "Wholesale inquiry"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line md:hidden",
							"aria-label": open ? "Close menu" : "Open menu",
							onClick: () => setOpen((v) => !v),
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					]
				}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-col gap-1 border-t border-line px-5 py-3 text-sm md:hidden",
					children: [
						["#product", "The pellet"],
						["#analysis", "Lab analysis"],
						["#benefits", "Why barns buy it"],
						["#process", "How it's made"],
						["#inquire", "Wholesale inquiry"]
					].map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href,
						className: "rounded-lg px-3 py-3 hover:bg-paper",
						onClick: () => setOpen(false),
						children: label
					}, href))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 md:grid-cols-12 md:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
									children: "Farm-direct equine supplement"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-4 font-display text-4xl leading-[1.1] tracking-tight text-forest-deep sm:text-6xl",
									children: "Hemp flower, pelletized for the feed tub."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-md text-lg text-muted",
									children: "Nutrient-dense flower separated from the stalk and pressed into a dense, uniform pellet. Joint comfort, a calmer disposition, coat shine, and digestion — in a 10 lb bag that barns actually finish."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap items-center gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "#inquire",
										className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-forest px-6 py-3 text-cream hover:bg-forest-deep",
										children: ["Talk to us ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
											className: "size-4",
											"aria-hidden": true
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#product",
										className: "min-h-11 px-2 py-3 text-sm text-forest underline-offset-4 hover:underline",
										children: "See the bag · $24.95"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-10 grid grid-cols-3 gap-4 border-t border-line pt-6 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Bag"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-display text-2xl text-forest-deep",
											children: "10 lb"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Price"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-display text-2xl text-forest-deep",
											children: "$24.95"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Per pound"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "font-display text-2xl text-forest-deep",
											children: "$2.50"
										})] })
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "md:col-span-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
								className: "overflow-hidden rounded-card shadow-[0_24px_60px_-28px_rgba(28,36,24,0.45)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/hero.jpg",
									alt: "Chestnut horse standing beside a hemp field at golden hour",
									className: "aspect-[16/10] w-full object-cover"
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "benefits",
						className: "border-y border-line bg-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-12 md:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
										children: "Why barns buy it"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-4xl tracking-tight text-forest-deep",
										children: "A supplement that reads like feed, not a boutique jar."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-muted",
										children: "Stencil-branded woven bags, priced for the feed room. Rich in cannabinoids, terpenes, essential fatty acids, and digestible fiber."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-4 md:col-span-7",
								children: benefits.map(({ icon: Icon, title, copy }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-4 rounded-card border border-line bg-cream p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 shrink-0 place-items-center rounded-full bg-forest text-cream",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											"aria-hidden": true
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-xl",
										children: title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted",
										children: copy
									})] })]
								}, title))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "product",
						className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "overflow-hidden rounded-card bg-paper",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/bag.jpg",
								alt: "Ten pound Equine Hemp feed bag on barn wood",
								className: "aspect-[3/4] w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
								children: "The bag"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl tracking-tight text-forest-deep",
								children: "10 pounds. Easy pour. Farm stencil."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-muted",
								children: "Industrial poly and woven feed bags with painted stencil branding — low unit cost, the look feed stores and barn managers already trust."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-8 divide-y divide-line border-y border-line",
								children: specs.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-6 py-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: k
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-right font-medium",
										children: v
									})]
								}, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#inquire",
								className: "mt-8 inline-flex min-h-11 items-center gap-2 rounded-full bg-gold px-6 py-3 text-forest-deep hover:bg-gold-soft",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, {
									className: "size-4",
									"aria-hidden": true
								}), " Request a case price"]
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "process",
						className: "bg-forest-deep text-cream",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2 md:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.22em] text-gold-soft",
									children: "How it's made"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl tracking-tight",
									children: "Flower in. Stalk out. Pellet on the line."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-8 space-y-6",
									children: [
										["Separate", "A mobile industrial trommel pulls nutrient-dense flower off the stalk."],
										["Press", "A 1,000 kg/hr mill compresses flower into dense, uniform pellets."],
										["Bag", "On-site packing into 10 lb easy-pour feed bags, ready for the barn aisle."]
									].map(([title, copy], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-2xl text-gold",
											children: String(i + 1).padStart(2, "0")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-xl",
											children: title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-gold-soft",
											children: copy
										})] })]
									}, title))
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
								className: "overflow-hidden rounded-card",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/pellets.jpg",
									alt: "Close view of dark green hemp pellets in a wooden scoop",
									className: "aspect-[4/3] w-full object-cover"
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "overflow-hidden rounded-card md:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/horse.jpg",
								alt: "Calm bay horse with a healthy coat in morning light",
								className: "aspect-[3/4] w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
									children: "For the people who buy feed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl tracking-tight text-forest-deep",
									children: "Built for feed stores, trainers, and barn managers."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-muted",
									children: "One SKU. A price that sits on a feed-store shelf without apology. First production is 300 round bales — a baseline of 9,000 ten-pound bags, with density upside to 10,000."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3",
									children: [
										["9,000", "baseline bags"],
										["300", "round bales"],
										["$2.50", "per pound"]
									].map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-card border border-line bg-paper p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-3xl text-forest",
											children: n
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: l
										})]
									}, l))
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "analysis",
						className: "border-t border-line bg-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl px-5 py-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
									children: "Certificate of analysis"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 max-w-2xl font-display text-4xl tracking-tight text-forest-deep",
									children: "X59 hemp flower, as tested."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-2xl text-muted",
									children: "A&L Canada Laboratories. Sample from Farmgates Farms, received 9 March 2026, reported 13 March 2026. Dry-matter basis unless noted. This bale was a 2018 harvest, stored under cover outdoors."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
									children: [
										[
											"19.35%",
											"Crude protein",
											"49% of that protein is soluble"
										],
										[
											"2.71",
											"Mcal/kg DE",
											"Equine digestible energy"
										],
										[
											"8.89%",
											"NSC",
											"Water-soluble sugars 6.50%"
										],
										[
											"196",
											"Relative feed value",
											"TDN 67.91%"
										]
									].map(([n, l, s]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-card border border-line bg-cream p-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-4xl text-forest",
												children: n
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 font-medium",
												children: l
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm text-muted",
												children: s
											})
										]
									}, l))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 overflow-x-auto rounded-card border border-line bg-cream",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full min-w-[36rem] text-left text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "border-b border-line text-muted",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Nutrient"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "X59 hemp flower"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Typical timothy"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3 font-medium",
													children: "Typical alfalfa"
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-line",
											children: [
												[
													"Crude protein",
													"19.35%",
													"8–12%",
													"15–20%"
												],
												[
													"Equine DE",
													"2.71 Mcal/kg",
													"1.8–2.2",
													"2.2–2.5"
												],
												[
													"ADF",
													"26.95%",
													"often 35%+",
													"30–35%"
												],
												[
													"NDF",
													"32.23%",
													"often 60%+",
													"40–50%"
												],
												[
													"Relative feed value",
													"196",
													"often 80–100",
													"full bloom ~100; prime 151+"
												],
												[
													"NSC",
													"8.89%",
													"often above 10%",
													"varies; often above 10%"
												]
											].map(([a, b, c, d]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-4 py-3 font-medium",
													children: a
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-4 py-3 text-forest",
													children: b
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-4 py-3 text-muted",
													children: c
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-4 py-3 text-muted",
													children: d
												})
											] }, a))
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xs text-muted",
									children: "Hay ranges are typical published figures for context, not a side-by-side test of the same lab run. Lower ADF and NDF usually mean higher digestibility and intake. An RFV of 196 sits above prime alfalfa and well above ordinary timothy."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-10 grid gap-8 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl text-forest-deep",
										children: "Minerals and fiber"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
										className: "mt-4 divide-y divide-line border-y border-line text-sm",
										children: [
											["Crude fat", "6.13%"],
											["Calcium", "2.75%"],
											["Potassium", "1.84%"],
											["Magnesium", "0.70%"],
											["Iron", "213 µg/g"],
											["Manganese", "197 µg/g"],
											["Zinc", "34.7 µg/g"],
											["Copper", "8.09 µg/g"],
											["Ash", "12.19%"],
											["Moisture, as fed", "12.28%"]
										].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between gap-4 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-muted",
												children: k
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "font-medium",
												children: v
											})]
										}, k))
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col justify-between gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-2xl text-forest-deep",
											children: "What eight years of storage did"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-muted",
											children: "Protein structures hold if the bale stays dry, and minerals do not fade. Vitamins A, D, and E do. Fat at 6.13% can oxidize in outdoor storage and turn bitter even when the lab sheet still looks strong. This sample still tested at 19.35% protein and RFV 196 in 2026, which says the 2018 cut was made at a good stage and kept dry. It is not a vitamin source. Fresh product from a current harvest is what we pellet for feed."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-card border border-line bg-cream p-5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-display text-xl text-forest-deep",
												children: "Custom cubes"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm text-muted",
												children: "A 15% inclusion in a timothy–alfalfa cube adds about 2.9 points of protein from this flower and keeps the hemp’s own NSC at 8.89%. Mills should check whether flower fines stay mixed, and whether the extra fat and 12% ash change steam and die pressure. Ask us if you want a spec sheet for a cube run."
											})]
										})]
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "inquire",
						className: "border-t border-line bg-paper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.22em] text-moss",
									children: "Wholesale"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl tracking-tight text-forest-deep",
									children: "Tell us the barn. We'll talk cases."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-muted",
									children: "Retail target is $24.95 CAD per 10 lb bag. Feed stores and trainers: ask for a case price. This form stays on your device — we'll show a confirmation you can screenshot until a direct line is live."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-xs text-muted",
									children: "Equine Hemp is a nutritional supplement, not a veterinary drug. It is not intended to diagnose, treat, cure, or prevent disease. Work with your veterinarian on any horse with a medical condition."
								})
							] }), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col justify-center rounded-card border border-line bg-cream p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl text-forest-deep",
										children: "Noted."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-muted",
										children: "We have your inquiry on this screen. Share it with the barn buyer, or send another if you run more than one yard."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "mt-6 w-fit rounded-full border border-forest px-5 py-2 text-sm text-forest",
										onClick: () => setSent(false),
										children: "Send another"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "grid gap-4 rounded-card border border-line bg-cream p-6",
								onSubmit: (e) => {
									e.preventDefault();
									setSent(true);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											name: "name",
											className: "min-h-11 rounded-lg border border-line bg-paper px-3"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: ["Barn or store", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											name: "barn",
											className: "min-h-11 rounded-lg border border-line bg-paper px-3"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "email",
											name: "email",
											className: "min-h-11 rounded-lg border border-line bg-paper px-3"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: ["What you need", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											name: "note",
											rows: 4,
											className: "rounded-lg border border-line bg-paper px-3 py-2",
											placeholder: "Cases, delivery window, horse count"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "min-h-11 rounded-full bg-forest px-6 text-cream hover:bg-forest-deep",
										children: "Request pricing"
									})
								]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-5 py-8 text-center text-sm text-muted",
				children: "Equine Hemp · Flower pellets for horses · Priced in CAD"
			})
		]
	});
}
//#endregion
export { Home as component };
