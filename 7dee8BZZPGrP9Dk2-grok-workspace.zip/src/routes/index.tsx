import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Leaf,
  Bone,
  HeartPulse,
  Sparkles,
  Package,
  ArrowRight,
  Menu,
  X,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: Home });

const benefits = [
  {
    icon: Bone,
    title: "Joint comfort",
    copy: "Flower-rich pellets carry naturally occurring cannabinoids and terpenes barns look for when supporting mobility on the daily ration.",
  },
  {
    icon: HeartPulse,
    title: "A quieter barn",
    copy: "Trainers use hemp flower as part of a calm-disposition routine — travel, show weeks, and horses that live a little loud.",
  },
  {
    icon: Sparkles,
    title: "Coat & digestion",
    copy: "Essential fatty acids plus digestible fiber in a dense pellet that pours cleanly into the feed tub.",
  },
];

const specs = [
  ["Bag", "10 lb easy-pour feed bag"],
  ["Price", "$24.95 CAD · $2.50 / lb"],
  ["Form", "Pelletized hemp flower"],
  ["Who it's for", "Barns, trainers, feed stores"],
];

function Home() {
  const [open, setOpen] = useState(false);
  const [sent, setSent] = useState(false);

  return (
    <div className="min-h-screen bg-cream text-ink">
      <header className="sticky top-0 z-30 border-b border-line/80 bg-cream/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <a href="#top" className="flex items-center gap-2 font-display text-lg tracking-tight">
            <span className="grid size-8 place-items-center rounded-full bg-forest text-cream">
              <Leaf className="size-4" aria-hidden />
            </span>
            Equine Hemp
          </a>
          <nav className="hidden items-center gap-8 text-sm text-muted md:flex">
            <a href="#product" className="hover:text-ink">The pellet</a>
            <a href="#analysis" className="hover:text-ink">Lab analysis</a>
            <a href="#benefits" className="hover:text-ink">Why barns buy it</a>
            <a href="#process" className="hover:text-ink">How it's made</a>
            <a href="#inquire" className="rounded-full bg-forest px-4 py-2 text-cream hover:bg-forest-deep">
              Wholesale inquiry
            </a>
          </nav>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {open && (
          <nav className="flex flex-col gap-1 border-t border-line px-5 py-3 text-sm md:hidden">
            {[
              ["#product", "The pellet"],
              ["#analysis", "Lab analysis"],
              ["#benefits", "Why barns buy it"],
              ["#process", "How it's made"],
              ["#inquire", "Wholesale inquiry"],
            ].map(([href, label]) => (
              <a
                key={href}
                href={href}
                className="rounded-lg px-3 py-3 hover:bg-paper"
                onClick={() => setOpen(false)}
              >
                {label}
              </a>
            ))}
          </nav>
        )}
      </header>

      <main id="top">
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-12 md:grid-cols-12 md:py-20">
          <div className="md:col-span-6">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">
              Farm-direct equine supplement
            </p>
            <h1 className="mt-4 font-display text-4xl leading-[1.1] tracking-tight text-forest-deep sm:text-6xl">
              Hemp flower, pelletized for the feed tub.
            </h1>
            <p className="mt-5 max-w-md text-lg text-muted">
              Nutrient-dense flower separated from the stalk and pressed into a dense, uniform pellet. Joint comfort, a calmer disposition, coat shine, and digestion — in a 10 lb bag that barns actually finish.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href="#inquire"
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-forest px-6 py-3 text-cream hover:bg-forest-deep"
              >
                Talk to us <ArrowRight className="size-4" aria-hidden />
              </a>
              <a href="#product" className="min-h-11 px-2 py-3 text-sm text-forest underline-offset-4 hover:underline">
                See the bag · $24.95
              </a>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-line pt-6 text-sm">
              <div>
                <dt className="text-muted">Bag</dt>
                <dd className="font-display text-2xl text-forest-deep">10 lb</dd>
              </div>
              <div>
                <dt className="text-muted">Price</dt>
                <dd className="font-display text-2xl text-forest-deep">$24.95</dd>
              </div>
              <div>
                <dt className="text-muted">Per pound</dt>
                <dd className="font-display text-2xl text-forest-deep">$2.50</dd>
              </div>
            </dl>
          </div>
          <div className="md:col-span-6">
            <figure className="overflow-hidden rounded-card shadow-[0_24px_60px_-28px_rgba(28,36,24,0.45)]">
              <img
                src="/hero.jpg"
                alt="Chestnut horse standing beside a hemp field at golden hour"
                className="aspect-[16/10] w-full object-cover"
              />
            </figure>
          </div>
        </section>

        <section id="benefits" className="border-y border-line bg-paper">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-12 md:items-center">
            <div className="md:col-span-5">
              <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">Why barns buy it</p>
              <h2 className="mt-3 font-display text-4xl tracking-tight text-forest-deep">
                A supplement that reads like feed, not a boutique jar.
              </h2>
              <p className="mt-4 text-muted">
                Stencil-branded woven bags, priced for the feed room. Rich in cannabinoids, terpenes, essential fatty acids, and digestible fiber.
              </p>
            </div>
            <ul className="grid gap-4 md:col-span-7">
              {benefits.map(({ icon: Icon, title, copy }) => (
                <li key={title} className="flex gap-4 rounded-card border border-line bg-cream p-5">
                  <span className="grid size-11 shrink-0 place-items-center rounded-full bg-forest text-cream">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <div>
                    <h3 className="font-display text-xl">{title}</h3>
                    <p className="mt-1 text-sm text-muted">{copy}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="product" className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-2">
          <figure className="overflow-hidden rounded-card bg-paper">
            <img
              src="/bag.jpg"
              alt="Ten pound Equine Hemp feed bag on barn wood"
              className="aspect-[3/4] w-full object-cover"
            />
          </figure>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">The bag</p>
            <h2 className="mt-3 font-display text-4xl tracking-tight text-forest-deep">
              10 pounds. Easy pour. Farm stencil.
            </h2>
            <p className="mt-4 text-muted">
              Industrial poly and woven feed bags with painted stencil branding — low unit cost, the look feed stores and barn managers already trust.
            </p>
            <dl className="mt-8 divide-y divide-line border-y border-line">
              {specs.map(([k, v]) => (
                <div key={k} className="flex items-baseline justify-between gap-6 py-3 text-sm">
                  <dt className="text-muted">{k}</dt>
                  <dd className="text-right font-medium">{v}</dd>
                </div>
              ))}
            </dl>
            <a
              href="#inquire"
              className="mt-8 inline-flex min-h-11 items-center gap-2 rounded-full bg-gold px-6 py-3 text-forest-deep hover:bg-gold-soft"
            >
              <Package className="size-4" aria-hidden /> Request a case price
            </a>
          </div>
        </section>

        <section id="process" className="bg-forest-deep text-cream">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2 md:items-center">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.22em] text-gold-soft">How it's made</p>
              <h2 className="mt-3 font-display text-4xl tracking-tight">Flower in. Stalk out. Pellet on the line.</h2>
              <ol className="mt-8 space-y-6">
                {[
                  ["Separate", "A mobile industrial trommel pulls nutrient-dense flower off the stalk."],
                  ["Press", "A 1,000 kg/hr mill compresses flower into dense, uniform pellets."],
                  ["Bag", "On-site packing into 10 lb easy-pour feed bags, ready for the barn aisle."],
                ].map(([title, copy], i) => (
                  <li key={title} className="flex gap-4">
                    <span className="font-display text-2xl text-gold">{String(i + 1).padStart(2, "0")}</span>
                    <div>
                      <h3 className="font-display text-xl">{title}</h3>
                      <p className="mt-1 text-sm text-gold-soft">{copy}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
            <figure className="overflow-hidden rounded-card">
              <img
                src="/pellets.jpg"
                alt="Close view of dark green hemp pellets in a wooden scoop"
                className="aspect-[4/3] w-full object-cover"
              />
            </figure>
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-5">
          <figure className="overflow-hidden rounded-card md:col-span-2">
            <img
              src="/horse.jpg"
              alt="Calm bay horse with a healthy coat in morning light"
              className="aspect-[3/4] w-full object-cover"
            />
          </figure>
          <div className="md:col-span-3">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">For the people who buy feed</p>
            <h2 className="mt-3 font-display text-4xl tracking-tight text-forest-deep">
              Built for feed stores, trainers, and barn managers.
            </h2>
            <p className="mt-4 max-w-xl text-muted">
              One SKU. A price that sits on a feed-store shelf without apology. First production is 300 round bales — a baseline of 9,000 ten-pound bags, with density upside to 10,000.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
              {[
                ["9,000", "baseline bags"],
                ["300", "round bales"],
                ["$2.50", "per pound"],
              ].map(([n, l]) => (
                <div key={l} className="rounded-card border border-line bg-paper p-4">
                  <p className="font-display text-3xl text-forest">{n}</p>
                  <p className="text-sm text-muted">{l}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="analysis" className="border-t border-line bg-paper">
          <div className="mx-auto max-w-6xl px-5 py-16">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">Certificate of analysis</p>
            <h2 className="mt-3 max-w-2xl font-display text-4xl tracking-tight text-forest-deep">
              X59 hemp flower, as tested.
            </h2>
            <p className="mt-4 max-w-2xl text-muted">
              A&L Canada Laboratories. Sample from Farmgates Farms, received 9 March 2026, reported 13 March 2026. Dry-matter basis unless noted. This bale was a 2018 harvest, stored under cover outdoors.
            </p>

            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ["19.35%", "Crude protein", "49% of that protein is soluble"],
                ["2.71", "Mcal/kg DE", "Equine digestible energy"],
                ["8.89%", "NSC", "Water-soluble sugars 6.50%"],
                ["196", "Relative feed value", "TDN 67.91%"],
              ].map(([n, l, s]) => (
                <div key={l} className="rounded-card border border-line bg-cream p-5">
                  <p className="font-display text-4xl text-forest">{n}</p>
                  <p className="mt-1 font-medium">{l}</p>
                  <p className="mt-1 text-sm text-muted">{s}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 overflow-x-auto rounded-card border border-line bg-cream">
              <table className="w-full min-w-[36rem] text-left text-sm">
                <thead className="border-b border-line text-muted">
                  <tr>
                    <th className="px-4 py-3 font-medium">Nutrient</th>
                    <th className="px-4 py-3 font-medium">X59 hemp flower</th>
                    <th className="px-4 py-3 font-medium">Typical timothy</th>
                    <th className="px-4 py-3 font-medium">Typical alfalfa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {[
                    ["Crude protein", "19.35%", "8–12%", "15–20%"],
                    ["Equine DE", "2.71 Mcal/kg", "1.8–2.2", "2.2–2.5"],
                    ["ADF", "26.95%", "often 35%+", "30–35%"],
                    ["NDF", "32.23%", "often 60%+", "40–50%"],
                    ["Relative feed value", "196", "often 80–100", "full bloom ~100; prime 151+"],
                    ["NSC", "8.89%", "often above 10%", "varies; often above 10%"],
                  ].map(([a, b, c, d]) => (
                    <tr key={a}>
                      <td className="px-4 py-3 font-medium">{a}</td>
                      <td className="px-4 py-3 text-forest">{b}</td>
                      <td className="px-4 py-3 text-muted">{c}</td>
                      <td className="px-4 py-3 text-muted">{d}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3 text-xs text-muted">
              Hay ranges are typical published figures for context, not a side-by-side test of the same lab run. Lower ADF and NDF usually mean higher digestibility and intake. An RFV of 196 sits above prime alfalfa and well above ordinary timothy.
            </p>

            <div className="mt-10 grid gap-8 md:grid-cols-2">
              <div>
                <h3 className="font-display text-2xl text-forest-deep">Minerals and fiber</h3>
                <dl className="mt-4 divide-y divide-line border-y border-line text-sm">
                  {[
                    ["Crude fat", "6.13%"],
                    ["Calcium", "2.75%"],
                    ["Potassium", "1.84%"],
                    ["Magnesium", "0.70%"],
                    ["Iron", "213 µg/g"],
                    ["Manganese", "197 µg/g"],
                    ["Zinc", "34.7 µg/g"],
                    ["Copper", "8.09 µg/g"],
                    ["Ash", "12.19%"],
                    ["Moisture, as fed", "12.28%"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-4 py-2">
                      <dt className="text-muted">{k}</dt>
                      <dd className="font-medium">{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
              <div className="flex flex-col justify-between gap-6">
                <div>
                  <h3 className="font-display text-2xl text-forest-deep">What eight years of storage did</h3>
                  <p className="mt-3 text-sm text-muted">
                    Protein structures hold if the bale stays dry, and minerals do not fade. Vitamins A, D, and E do. Fat at 6.13% can oxidize in outdoor storage and turn bitter even when the lab sheet still looks strong. This sample still tested at 19.35% protein and RFV 196 in 2026, which says the 2018 cut was made at a good stage and kept dry. It is not a vitamin source. Fresh product from a current harvest is what we pellet for feed.
                  </p>
                </div>
                <div className="rounded-card border border-line bg-cream p-5">
                  <h3 className="font-display text-xl text-forest-deep">Custom cubes</h3>
                  <p className="mt-2 text-sm text-muted">
                    A 15% inclusion in a timothy–alfalfa cube adds about 2.9 points of protein from this flower and keeps the hemp’s own NSC at 8.89%. Mills should check whether flower fines stay mixed, and whether the extra fat and 12% ash change steam and die pressure. Ask us if you want a spec sheet for a cube run.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="inquire" className="border-t border-line bg-paper">
          <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-2">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.22em] text-moss">Wholesale</p>
              <h2 className="mt-3 font-display text-4xl tracking-tight text-forest-deep">
                Tell us the barn. We'll talk cases.
              </h2>
              <p className="mt-4 text-muted">
                Retail target is $24.95 CAD per 10 lb bag. Feed stores and trainers: ask for a case price. This form stays on your device — we'll show a confirmation you can screenshot until a direct line is live.
              </p>
              <p className="mt-6 text-xs text-muted">
                Equine Hemp is a nutritional supplement, not a veterinary drug. It is not intended to diagnose, treat, cure, or prevent disease. Work with your veterinarian on any horse with a medical condition.
              </p>
            </div>
            {sent ? (
              <div className="flex flex-col justify-center rounded-card border border-line bg-cream p-8">
                <p className="font-display text-3xl text-forest-deep">Noted.</p>
                <p className="mt-3 text-muted">
                  We have your inquiry on this screen. Share it with the barn buyer, or send another if you run more than one yard.
                </p>
                <button
                  type="button"
                  className="mt-6 w-fit rounded-full border border-forest px-5 py-2 text-sm text-forest"
                  onClick={() => setSent(false)}
                >
                  Send another
                </button>
              </div>
            ) : (
              <form
                className="grid gap-4 rounded-card border border-line bg-cream p-6"
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
              >
                <label className="grid gap-1 text-sm">
                  Name
                  <input required name="name" className="min-h-11 rounded-lg border border-line bg-paper px-3" />
                </label>
                <label className="grid gap-1 text-sm">
                  Barn or store
                  <input required name="barn" className="min-h-11 rounded-lg border border-line bg-paper px-3" />
                </label>
                <label className="grid gap-1 text-sm">
                  Email
                  <input required type="email" name="email" className="min-h-11 rounded-lg border border-line bg-paper px-3" />
                </label>
                <label className="grid gap-1 text-sm">
                  What you need
                  <textarea name="note" rows={4} className="rounded-lg border border-line bg-paper px-3 py-2" placeholder="Cases, delivery window, horse count" />
                </label>
                <button type="submit" className="min-h-11 rounded-full bg-forest px-6 text-cream hover:bg-forest-deep">
                  Request pricing
                </button>
              </form>
            )}
          </div>
        </section>
      </main>

      <footer className="border-t border-line px-5 py-8 text-center text-sm text-muted">
        Equine Hemp · Flower pellets for horses · Priced in CAD
      </footer>
    </div>
  );
}
