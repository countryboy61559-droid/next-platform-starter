const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
        ShadingType, PageNumber, LevelFormat, VerticalAlign } = require('docx');
const fs = require('fs');

// Border styles
const thinBorder = { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" };
const thinBorders = { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder };
const headerBorder = { style: BorderStyle.SINGLE, size: 4, color: "1B4F72" };
const headerBorders = { top: headerBorder, bottom: headerBorder, left: headerBorder, right: headerBorder };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

// Helper for table header cell
function headerCell(text, width) {
  return new TableCell({
    borders: headerBorders,
    width: { size: width, type: WidthType.DXA },
    shading: { fill: "1B4F72", type: ShadingType.CLEAR },
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      children: [new TextRun({ text, bold: true, color: "FFFFFF", size: 18, font: "Arial" })]
    })]
  });
}

// Helper for table data cell
function dataCell(text, width, opts = {}) {
  const { bold = false, align = AlignmentType.LEFT, fill = null, color = "333333" } = opts;
  return new TableCell({
    borders: thinBorders,
    width: { size: width, type: WidthType.DXA },
    shading: fill ? { fill, type: ShadingType.CLEAR } : undefined,
    margins: { top: 60, bottom: 60, left: 100, right: 100 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      alignment: align,
      children: [new TextRun({ text, bold, size: 18, font: "Arial", color })]
    })]
  });
}

const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: "Arial", size: 22 }
      }
    },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: "1B4F72" },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 }
      },
      {
        id: "Heading2",
        name: "Heading 2",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 24, bold: true, font: "Arial", color: "2874A6" },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 }
      },
      {
        id: "Title",
        name: "Title",
        basedOn: "Normal",
        quickFormat: true,
        run: { size: 40, bold: true, font: "Arial", color: "1B4F72" },
        paragraph: { spacing: { before: 0, after: 120 }, alignment: AlignmentType.CENTER }
      }
    ]
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      },
      {
        reference: "numbers",
        levels: [{
          level: 0,
          format: LevelFormat.DECIMAL,
          text: "%1.",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      },
      {
        reference: "phase1-bullets",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      },
      {
        reference: "phase2-bullets",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      },
      {
        reference: "protections",
        levels: [{
          level: 0,
          format: LevelFormat.DECIMAL,
          text: "%1.",
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      }
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 }
      }
    },
    headers: {
      default: new Header({
        children: [
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            children: [
              new TextRun({ text: "CONFIDENTIAL — Investment Proposal", size: 16, italics: true, color: "666666", font: "Arial" })
            ]
          })
        ]
      })
    },
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: "Equine Hemp Pelletizing Initiative  |  Page ", size: 16, color: "666666", font: "Arial" }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: "666666", font: "Arial" }),
              new TextRun({ text: " of ", size: 16, color: "666666", font: "Arial" }),
              new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, color: "666666", font: "Arial" })
            ]
          })
        ]
      })
    },
    children: [
      // Title
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 80 },
        children: [new TextRun({ text: "INVESTMENT PROPOSAL", bold: true, size: 36, font: "Arial", color: "1B4F72" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 200 },
        children: [new TextRun({ text: "Equine Hemp Pelletizing Initiative", bold: true, size: 32, font: "Arial", color: "2874A6" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: "1B4F72", space: 8 } },
        children: [new TextRun({ text: "Capital Request: $25,000 CAD  |  Projected ROI: 377.7%", size: 20, font: "Arial", color: "555555" })]
      }),

      // 1. Executive Summary
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("1. Executive Summary")]
      }),
      new Paragraph({
        spacing: { after: 120 },
        children: [new TextRun({
          text: "A capital investment of $25,000 CAD is requested to finance the processing, pelletizing, and packaging of 300 round bales of premium hemp into a high-value equine nutritional supplement. By separating the nutrient-dense flower from the stalk and processing it through a commercial pelletizer, this operation will produce a baseline of 90,000 lbs of finished product packaged in 10 lb bags.",
          size: 20
        })]
      }),
      new Paragraph({
        spacing: { after: 120 },
        children: [new TextRun({
          text: "With an established retail target of $24.95 CAD per 10 lb bag, the baseline inventory represents a gross market value of $224,550 CAD. The investment opportunity offers an accelerated capital recovery structure (70% of gross revenues until principal is repaid) followed by an ongoing 50/50 profit distribution, yielding a projected 377.6% Return on Investment (ROI) on the initial run alongside a Right of First Refusal for subsequent processing rounds.",
          size: 20
        })]
      }),

      // 2. Market Opportunity
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("2. Market Opportunity & Product Strategy")]
      }),
      new Paragraph({
        spacing: { after: 120 },
        children: [new TextRun({
          text: "Hemp flower pellets serve as an all-natural, high-potency supplement in the equine health and performance sector. Rich in beneficial cannabinoids, terpenes, essential fatty acids, and digestible fiber, hemp pellets support joint mobility, calm disposition, coat health, and digestive function in horses.",
          size: 20
        })]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Format: ", bold: true, size: 20 }),
          new TextRun({ text: "10 lb easy-pour feed bags.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Target Retail/Wholesale Price: ", bold: true, size: 20 }),
          new TextRun({ text: "$24.95 per bag ($2.50/lb).", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 120 },
        children: [
          new TextRun({ text: "Cost Control Strategy: ", bold: true, size: 20 }),
          new TextRun({ text: "Packaging overhead is minimized by utilizing bulk industrial poly/woven feed bags paired with proprietary, high-durability painted stencil branding. This maintains low unit cost while presenting an authentic, farm-direct visual appeal to feed stores, trainers, and barn managers.", size: 20 })
        ]
      }),

      // 3. Operational Blueprint
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("3. Operational Blueprint & Labor Structure")]
      }),
      new Paragraph({
        spacing: { after: 120 },
        children: [new TextRun({
          text: "Processing will take place over a budgeted 10-day operational window. The workflow integrates mechanical separation, direct pellet extrusion, and on-site bagging.",
          size: 20
        })]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Equipment & Throughput")]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Separation: ", bold: true, size: 20 }),
          new TextRun({ text: "Mobile industrial trommel to isolate flower material from stalks.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Material Handling: ", bold: true, size: 20 }),
          new TextRun({ text: "Dedicated skid steer for staging and loading round bales into the trommel hopper.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 120 },
        children: [
          new TextRun({ text: "Pelletizing: ", bold: true, size: 20 }),
          new TextRun({ text: "A 1,000 kg/hr commercial pelletizing mill imported directly from the manufacturer to compress flower into dense, uniform pellets.", size: 20 })
        ]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Operational Capacity & Timeline Buffer")]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Conservative Baseline: ", bold: true, size: 20 }),
          new TextRun({ text: "Budgeted at 30 bales per day (300 bales completed in 10 operational days).", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 120 },
        children: [
          new TextRun({ text: "Throughput Upside: ", bold: true, size: 20 }),
          new TextRun({ text: "The equipment configuration is rated for up to 50 bales per day. Running at maximum efficiency would compress the cycle to 6–7 days, reducing daily equipment rental burn and further expanding net margins. The 10-day financial model serves as a conservative operational ceiling.", size: 20 })
        ]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Lean Labor & Founder Alignment")]
      }),
      new Paragraph({
        spacing: { after: 80 },
        children: [new TextRun({ text: "Operational labor is strictly capped and does not scale upward with volume:", size: 20 })]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Field Operators: ", bold: true, size: 20 }),
          new TextRun({ text: "Two dedicated operators at a fixed rate of $250/day each for machine operation, bale handling, and packing.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Owner-Operator On-Site: ", bold: true, size: 20 }),
          new TextRun({ text: "The business founder works directly on the line full-time as the third operator and site manager.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 120 },
        children: [
          new TextRun({ text: "Skin in the Game: ", bold: true, size: 20 }),
          new TextRun({ text: "The founder draws $0 in management salary or hourly payroll. Founder compensation is realized strictly through performance via retained revenue splits (30% during the capital recovery phase; 50% thereafter), ensuring complete alignment with investor success.", size: 20 })
        ]
      }),

      // 4. Use of Funds
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("4. Use of Funds & Capital Budget")]
      }),
      new Paragraph({
        spacing: { after: 160 },
        children: [new TextRun({
          text: "The $25,000 CAD capital facility completely funds machine acquisition, heavy equipment rental, specialized labor, packaging, and operating reserves.",
          size: 20
        })]
      }),

      // Budget Table
      new Table({
        width: { size: 10080, type: WidthType.DXA },
        columnWidths: [1440, 4320, 1800, 2520],
        rows: [
          new TableRow({
            children: [
              headerCell("Category", 1440),
              headerCell("Item Description", 4320),
              headerCell("Allocation (CAD)", 1800),
              headerCell("Asset Status", 2520)
            ]
          }),
          new TableRow({
            children: [
              dataCell("CapEx", 1440, { bold: true }),
              dataCell("1,000 kg/hr Commercial Pelletizing Machine (Imported)", 4320),
              dataCell("$5,000.00", 1800, { align: AlignmentType.RIGHT }),
              dataCell("Owned Equity Asset", 2520)
            ]
          }),
          new TableRow({
            children: [
              dataCell("OpEx", 1440, { bold: true, fill: "F5F8FA" }),
              dataCell("Industrial Trommel Rental ($6,500/week, pro-rated 10 days)", 4320, { fill: "F5F8FA" }),
              dataCell("$9,286.00", 1800, { align: AlignmentType.RIGHT, fill: "F5F8FA" }),
              dataCell("Leased Expense", 2520, { fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("OpEx", 1440, { bold: true }),
              dataCell("Skid Steer Rental ($400/day × 10 days)", 4320),
              dataCell("$4,000.00", 1800, { align: AlignmentType.RIGHT }),
              dataCell("Leased Expense", 2520)
            ]
          }),
          new TableRow({
            children: [
              dataCell("OpEx", 1440, { bold: true, fill: "F5F8FA" }),
              dataCell("Hired Labor (2 Machine Operators @ $250/day × 10 days)", 4320, { fill: "F5F8FA" }),
              dataCell("$5,000.00", 1800, { align: AlignmentType.RIGHT, fill: "F5F8FA" }),
              dataCell("Fixed Labor", 2520, { fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Working Capital", 1440, { bold: true }),
              dataCell("Bulk Bags, Paint-On Labeling Supplies, Fuel & Contingency", 4320),
              dataCell("$1,714.00", 1800, { align: AlignmentType.RIGHT }),
              dataCell("Consumables", 2520)
            ]
          }),
          new TableRow({
            children: [
              dataCell("Total", 1440, { bold: true, fill: "D4E6F1" }),
              dataCell("Full Turnkey Capital Requirement", 4320, { bold: true, fill: "D4E6F1" }),
              dataCell("$25,000.00", 1800, { bold: true, align: AlignmentType.RIGHT, fill: "D4E6F1" }),
              dataCell("", 2520, { fill: "D4E6F1" })
            ]
          })
        ]
      }),

      new Paragraph({
        spacing: { before: 160, after: 120 },
        children: [
          new TextRun({ text: "Note: ", bold: true, italics: true, size: 18 }),
          new TextRun({ text: "Following Batch 1 completion, the pelletizing machine remains 100% owned unencumbered equity, eliminating this $5,000 CapEx expense from future production runs.", italics: true, size: 18, color: "555555" })
        ]
      }),

      // 5. Production Yield
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("5. Production Yield & Revenue Potential")]
      }),
      new Paragraph({
        spacing: { after: 160 },
        children: [new TextRun({
          text: "The operation holds 300 round hemp bales yielding an average of 300 lbs of separated flower per bale. Because dense floral material varies across harvest lots, financial projections reflect both conservative baseline yields and potential density upside.",
          size: 20
        })]
      }),

      new Table({
        width: { size: 10080, type: WidthType.DXA },
        columnWidths: [3600, 3240, 3240],
        rows: [
          new TableRow({
            children: [
              headerCell("Metric", 3600),
              headerCell("Baseline Production Model", 3240),
              headerCell("High-Yield Upside Model", 3240)
            ]
          }),
          new TableRow({
            children: [
              dataCell("Raw Material", 3600, { bold: true }),
              dataCell("300 Round Bales", 3240, { align: AlignmentType.CENTER }),
              dataCell("300 Round Bales", 3240, { align: AlignmentType.CENTER })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Average Flower Yield / Bale", 3600, { bold: true, fill: "F5F8FA" }),
              dataCell("300 lbs", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" }),
              dataCell("333 lbs", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Total Pelletized Flower Weight", 3600, { bold: true }),
              dataCell("90,000 lbs", 3240, { align: AlignmentType.CENTER }),
              dataCell("100,000 lbs", 3240, { align: AlignmentType.CENTER })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Bag Unit Size", 3600, { bold: true, fill: "F5F8FA" }),
              dataCell("10 lbs", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" }),
              dataCell("10 lbs", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Finished Packaged Units", 3600, { bold: true }),
              dataCell("9,000 Bags", 3240, { align: AlignmentType.CENTER }),
              dataCell("10,000 Bags", 3240, { align: AlignmentType.CENTER })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Unit Sale Price", 3600, { bold: true, fill: "F5F8FA" }),
              dataCell("$24.95 CAD", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" }),
              dataCell("$24.95 CAD", 3240, { align: AlignmentType.CENTER, fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Total Gross Revenue", 3600, { bold: true, fill: "D4E6F1" }),
              dataCell("$224,550.00 CAD", 3240, { bold: true, align: AlignmentType.CENTER, fill: "D4E6F1" }),
              dataCell("$249,500.00 CAD", 3240, { bold: true, align: AlignmentType.CENTER, fill: "D4E6F1" })
            ]
          })
        ]
      }),

      // 6. Investor Waterfall
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("6. Investor Waterfall Distribution & Return Analysis")]
      }),
      new Paragraph({
        spacing: { after: 120 },
        children: [new TextRun({
          text: "Revenue distribution begins within 45 days of final batch packaging. Cash distributions follow a two-tier waterfall structure designed to de-risk investor capital rapidly.",
          size: 20
        })]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Phase 1: Rapid Capital Payback (70 / 30 Split)")]
      }),
      new Paragraph({
        numbering: { reference: "phase1-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Mechanism: ", bold: true, size: 20 }),
          new TextRun({ text: "70% of gross top-line receipts are remitted directly to the investor until the original $25,000 CAD principal is paid in full.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase1-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Breakeven Volume: ", bold: true, size: 20 }),
          new TextRun({ text: "Full capital recovery requires gross revenue of $35,714.29 CAD.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase1-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Inventory Required: ", bold: true, size: 20 }),
          new TextRun({ text: "Only 1,432 bags (15.9% of total production) must be sold to return 100% of the invested principal. The remaining 84.1% of inventory (7,568 bags) is pure profit margin.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase1-bullets", level: 0 },
        spacing: { after: 120 },
        children: [
          new TextRun({ text: "Founder Share: ", bold: true, size: 20 }),
          new TextRun({ text: "The remaining 30% ($10,714.29 CAD) covers initial distribution logistics and founder sweat equity.", size: 20 })
        ]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Phase 2: Commercial Profit Sharing (50 / 50 Split)")]
      }),
      new Paragraph({
        numbering: { reference: "phase2-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Mechanism: ", bold: true, size: 20 }),
          new TextRun({ text: "Upon reaching the $25,000 payback threshold, all remaining revenue shifts to an equal 50/50 profit split between investor and founder.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase2-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Remaining Revenue Pool: ", bold: true, size: 20 }),
          new TextRun({ text: "$224,550.00 − $35,714.29 = $188,835.71 CAD.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase2-bullets", level: 0 },
        spacing: { after: 60 },
        children: [
          new TextRun({ text: "Investor Share (50%): ", bold: true, size: 20 }),
          new TextRun({ text: "$94,417.86 CAD.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "phase2-bullets", level: 0 },
        spacing: { after: 160 },
        children: [
          new TextRun({ text: "Founder Share (50%): ", bold: true, size: 20 }),
          new TextRun({ text: "$94,417.86 CAD.", size: 20 })
        ]
      }),

      new Paragraph({
        heading: HeadingLevel.HEADING_2,
        children: [new TextRun("Total Financial Return (Baseline Model)")]
      }),
      new Paragraph({
        spacing: { after: 80 },
        children: [
          new TextRun({ text: "Net Investor Profit = $119,417.86 − $25,000.00 = $94,417.86 CAD", size: 20 })
        ]
      }),
      new Paragraph({
        spacing: { after: 160 },
        children: [
          new TextRun({ text: "Return on Investment (ROI) = ($94,417.86 / $25,000.00) × 100 = 377.67%", size: 20 })
        ]
      }),

      new Table({
        width: { size: 10080, type: WidthType.DXA },
        columnWidths: [6480, 3600],
        rows: [
          new TableRow({
            children: [
              headerCell("Financial Summary (Baseline 9,000 Bags)", 6480),
              headerCell("Value (CAD)", 3600)
            ]
          }),
          new TableRow({
            children: [
              dataCell("Initial Investment Capital", 6480),
              dataCell("$25,000.00", 3600, { align: AlignmentType.RIGHT })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Phase 1 Principal Repayment", 6480, { fill: "F5F8FA" }),
              dataCell("$25,000.00", 3600, { align: AlignmentType.RIGHT, fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Phase 2 Profit Distribution", 6480),
              dataCell("$94,417.86", 3600, { align: AlignmentType.RIGHT })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Total Cumulative Cash Returned to Investor", 6480, { bold: true, fill: "D4E6F1" }),
              dataCell("$119,417.86", 3600, { bold: true, align: AlignmentType.RIGHT, fill: "D4E6F1" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Net Cash Profit", 6480, { fill: "F5F8FA" }),
              dataCell("$94,417.86", 3600, { align: AlignmentType.RIGHT, fill: "F5F8FA" })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Cash-on-Cash Return Multiple", 6480),
              dataCell("4.78×", 3600, { align: AlignmentType.RIGHT })
            ]
          }),
          new TableRow({
            children: [
              dataCell("Total Project ROI", 6480, { bold: true, fill: "D5F5E3" }),
              dataCell("377.7%", 3600, { bold: true, align: AlignmentType.RIGHT, fill: "D5F5E3", color: "1A5276" })
            ]
          })
        ]
      }),

      new Paragraph({
        spacing: { before: 160, after: 120 },
        children: [
          new TextRun({ text: "Note: ", bold: true, italics: true, size: 18 }),
          new TextRun({ text: "Under the 10,000-bag upside yield scenario, total investor payout expands to $131,892.86 CAD, delivering a 427.6% ROI / 5.28× multiple.", italics: true, size: 18, color: "555555" })
        ]
      }),

      // 7. Investor Rights
      new Paragraph({
        heading: HeadingLevel.HEADING_1,
        children: [new TextRun("7. Investor Rights & Downside Protections")]
      }),
      new Paragraph({
        numbering: { reference: "protections", level: 0 },
        spacing: { after: 100 },
        children: [
          new TextRun({ text: "Seniority of Capital: ", bold: true, size: 20 }),
          new TextRun({ text: "Investor distributions sit senior to all operational profits. No business profits are retained by the management team until the $25,000 investment is settled in full.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "protections", level: 0 },
        spacing: { after: 100 },
        children: [
          new TextRun({ text: "Asset Collateralization: ", bold: true, size: 20 }),
          new TextRun({ text: "The commercial 1,000 kg/hr pelletizer purchased with the investment capital ($5,000 asset value) acts as tangible asset backing throughout the duration of the project.", size: 20 })
        ]
      }),
      new Paragraph({
        numbering: { reference: "protections", level: 0 },
        spacing: { after: 200 },
        children: [
          new TextRun({ text: "Right of First Refusal (ROFR): ", bold: true, size: 20 }),
          new TextRun({ text: "The investor receives an exclusive contractual Right of First Refusal to finance Round 2 processing operations. In Round 2, operational efficiency will be substantially higher as the pelletizing infrastructure will already be fully amortized and on-site.", size: 20 })
        ]
      }),

      // Closing line
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200 },
        border: { top: { style: BorderStyle.SINGLE, size: 6, color: "1B4F72", space: 12 } },
        children: [new TextRun({ text: "— End of Proposal —", size: 18, italics: true, color: "666666", font: "Arial" })]
      })
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/home/workdir/artifacts/Equine_Hemp_Pelletizing_Investment_Proposal.docx", buffer);
  console.log("Document created successfully.");
});
